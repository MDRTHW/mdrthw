#include <stdio.h>
void del(char info[],int link[],int start,int avail,int loc,int locp)
{if(locp==-1)
start=link[start];
else
link[locp]=link[loc];
link[loc]=avail;
avail=loc;}
int main()
{int link[]={9,-1,7,-1,10,2,4,6,0,11,3,1};
int info[]={'x','x','u','e','c','r','t','e','x','x','s','x'};
int start=5, loc=3,locp=10,avail=0;
int ptr=5;
del(info,link,start,avail,loc,locp);
return 0;}

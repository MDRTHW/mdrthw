#include <stdio.h>
int main()
{char info[]={'E','x','x','R','x','U','x','T'};
int forw[]={7,-1,3,5,-1,0,-1,2};
int back[]={5,-1,7,-1,-1,3,-1,0};
int start=2,ptr,loc=-1;
char item='U';
ptr=back[start];
while(info[ptr]!=item&&ptr!=start)
{ptr=back[ptr];}
if(info[ptr]==item)
loc=ptr;
else
loc=-1;
printf("LOCATION= %d",loc+1);
return 0;}

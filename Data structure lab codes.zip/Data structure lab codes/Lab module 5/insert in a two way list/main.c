#include <stdio.h>
void insert(char info[],int forw[],int back[], int start, int avail, int loca, int locb, char item)
{int neww;
if(avail==-1)
{printf("OVERFLOW\n");
return;}
neww=avail;
avail=forw[avail];
info[neww]=item;
forw[loca]=neww;
forw[neww]=locb;
back[locb]=neww;
back[neww]=loca;}
int main()
{char info[]={'E','x','x','R','x','U','x','T'};
int forw[]={7,-1,3,5,-1,0,-1,2};
int back[]={5,-1,7,-1,-1,3,-1,0};
int start=2,ptr,avail=1,loca=0,locb=7;
char item='E';
ptr=forw[start];
insert(info,forw,back,start,avail,loca,locb,item);
while(ptr!=start)
{printf("%c",info[ptr]);
ptr=forw[ptr];}
return 0;}

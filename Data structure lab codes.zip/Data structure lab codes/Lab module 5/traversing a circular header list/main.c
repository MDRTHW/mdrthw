#include <stdio.h>
int main()
{char info[]={'E','x','x','R','x','U','x','T'};
int forw[]={7,-1,3,5,-1,0,-1,2};
int back[]={5,-1,7,-1,-1,3,-1,0};
int start=2,ptr;
ptr=back[start];
while(ptr!=start)
{printf("%c",info[ptr]);
ptr=back[ptr];}
return 0;}

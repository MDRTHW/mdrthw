#include <stdio.h>
void deln(char info[],int forw[],int back[],int start, int avail, int loc)
{forw[back[loc]]=forw[loc];
back[forw[loc]]=back[loc];
forw[loc]=avail;
avail=loc;
back[loc]=-1;}
int main()
{char info[]={'E','x','x','R','x','U','x','T'};
int forw[]={7,-1,3,5,-1,0,-1,2};
int back[]={5,-1,7,-1,-1,3,-1,0};
int start=2,ptr,avail=1,loc=5;
ptr=forw[start];
deln(info,forw,back,start,avail,loc);
while(ptr!=start)
{printf("%c",info[ptr]);
ptr=forw[ptr];}
return 0;}

#include <stdio.h>
 char stack[100]={'R','A','H','A','T'};
 int top=4,maxtop=99;



void push(char item)
{
    if(top==maxtop)
    {
        printf("Overflow.Returning...");
        return;
    }
    top=top+1;
    stack[top]=item;
    return;
}

int main()
{
    int i;
    push('I');
    for(i=0;i<=top;i++)
    printf("%c",stack[i]);
    return 0;
}

#include <stdio.h>
 char stack[100]={'R','A','H','A','T'};
 int top=4,maxtop=99;


void pop()
{
    char item;
    if(top==0)
    {
        printf("Underflow.Returning...\n");
        return;
    }
    item = stack[top];
    top=top-1;
    return;
}

int main()
{
    int i;
    pop();
for(i=0;i<=top;i++)
    printf("%c",stack[i]);
    printf("\n");

    return 0;
}

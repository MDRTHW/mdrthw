#include <stdio.h>
int insloc(char info[],int link[],int start,int avail,int loc,char item)
{int nnew;
if(avail==-1) return -3;
nnew=avail;
avail=link[avail];
info[nnew]=item;
if(loc==-1){link[nnew]=start; start=nnew;}
else {link[nnew]=link[loc]; link[loc]=nnew;}
return 0;}
int main()
{char info[]={'X','B','T','O','X','R','A','H'};
int link[]={-1,-1,5,3,6,-1,1,-1};
insloc(info,link,3,4,4,'Q');
return 0;}

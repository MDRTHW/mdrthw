#include <stdio.h>
#include <stdlib.h>


int search(char info[],int link[],int start, char iteam)
{
    int ptr,loc;
    ptr=start;
    while(ptr!=-1)
    {
        if(iteam==info[ptr])
        {
            loc=ptr;
            return loc;
        }
        else
            ptr=link[ptr];
    }
    return -1;
}

int main()
{
    int link[12]={-1,-1,8,-1,11,3,5,7,-1,-1,4,-1};
    char info[12]={'0','0','U','E','C','R','T','E','0','0','s','0'};
    int loc;
    loc=search(info,link,4,'C');
    printf("LOCATION:%d\n",loc);
    return 0;
}

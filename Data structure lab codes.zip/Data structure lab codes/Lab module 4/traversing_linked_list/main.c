#include <stdio.h>
#include <stdlib.h>

int main()
{
    int start=6,ptr=-1;
    ptr=start;
    int link[12]={-1,-1,8,-1,11,3,5,7,-1,-1,4,-1};
    char info[12]={'0','0','U','E','C','R','T','E','0','0','s','0'};
    while(ptr!=-1)
    {
        printf("%c ",info[ptr]);
        ptr=link[ptr];
    }
    printf("\n");
    return 0;
}

#include <stdio.h>
int insfirst(char info[],int link[],int start,int avail,char item)
{int nnew;
if(avail==-1) return -2;
nnew=avail;
avail=link[avail;
info[nnew]=item;
link[nnew]=start;
start=nnew;
return 0;}
int main()
{char info[]={'X','B','T','O','X','R','A','H'};
int link[]={-1,-1,5,3,6,-1,1,-1};
insfirst(info,link,3,4,'Q');
return 0;}

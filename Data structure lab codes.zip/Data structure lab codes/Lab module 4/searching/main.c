#include <stdio.h>
int search(int info[],int link[],int start,int ieam)
{int ptr,loc;
ptr=start;
while(ptr!=-1){
if(iteam==info[ptr-1])
{loc=ptr;return loc;}
else
ptr=link[ptr-1];}
return -1;}
int main()
{int info[]={-1,-1,201,402,325,101,301,251,-1,-1,385,-1};
int link[]={-1,-1,8,11,3,5,7,-1,-1,4,-1};
int loc;
loc=search(info,link,7,301);
printf("%d ",loc);
return 0;}

#include <stdio.h>
int finda(char info[],int link[],int start,int loc,char item)
{int save,ptr;
if(start==-1)
{loc=-1; returnloc;}
if(item<info[start])
{loc=-1; return loc;}
save=start;
ptr=link[start];
while(ptr!=-1){
if(item<info[ptr])
{loc=save; return loc;}
save=ptr;  ptr=link[ptr];}
loc=save; return loc;}
int main()
{char info[]={'X','B','T','O','X','R','A','H'};
int link[]={-1,-1,5,3,6,-1,1,-1};
finda(info,link,3,4,'Q');
return 0;}

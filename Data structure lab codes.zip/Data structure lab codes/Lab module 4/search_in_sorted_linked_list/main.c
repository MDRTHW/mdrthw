#include <stdio.h>
int srchsl(int info[],int link[],int srart, int item)
{int ptr,loc;
ptr=start;
while(ptr!=-1){
if(item>info[ptr-1]) ptr=link[ptr-1];
else if(item==info[ptr-1]) {loc=ptr; return loc;}
else {loc=-1; return -1;}}
loc=-1; return -1;}
int main()
{int  info[12]={-1,-1,101,201,251,301,325,385,-1,-1,402,-1};
int link[12]={-1,-18,-1,11,3,5,7,-1,-1,4,-1};
int loc;
loc=srchsl(info,link,6,402);
printf("Hello world!\n");
return 0;}

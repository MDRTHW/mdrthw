#include <stdio.h>

struct student {
    int roll;
    char name[20];
    float gpa;
};

int main()
{
   struct student s1[30];
   int i,a;
   for(i=0;i<30;i++)
   {
       printf("give new data:\n");
       scanf("%d",&s1[i].roll);
       scanf("%s",s1[i].name);
       scanf("%f",&s1[i].gpa);
   }
 printf("Give a roll to find the data: ");
 scanf("%d",&a);
 printf("Roll: %d   Name: %s   GPA: %f\n",s1[a-1].roll,s1[a-1].name,s1[a-1].gpa);
    return 0;
}

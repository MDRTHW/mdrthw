#include <stdio.h>

int main()
{
    int a[30][5];
    int i,j,k=0;



    for(i=0;i<5;i++)
    {
        printf("Give new data: ");
        for(j=0;j<5;j++)
        {
            if(j==0)
                scanf("%d",&a[i][j]);
           else if(j==1)
                scanf("%d",&a[i][j]);
            else if(j==2)
             scanf("%d",&a[i][j]);
            else if(j==3)
             scanf("%d",&a[i][j]);
            else
             scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<5;i++)
    {
        k=a[i][4];
        printf("Data are:");
        for(j=0;j<5;j++)
        {

             if(j==0)
                printf("%d ",a[k][j]);
           else if(j==1)
                printf("%d ",a[k][j]);
            else if(j==2)
             printf("%d ",a[k][j]);
            else if(j==3)
             printf("%d ",a[k][j]);
            else
             printf("%d ",a[k][j]);
        }
        printf("\n");
          k=a[i][4];
        printf("%d\n",i);
        if(a[i][4]==0)
            break;
    }
    return 0;
}

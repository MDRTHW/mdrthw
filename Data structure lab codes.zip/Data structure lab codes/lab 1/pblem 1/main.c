#include <stdio.h>

struct student {
    int roll;
    char name[20];
    float gpa;
};

int main()
{
   struct student s1[30];
   int i;
   for(i=0;i<30;i++)
   {
       printf("give new data:\n");
       scanf("%d",&s1[i].roll);
       scanf("%s",s1[i].name);
       scanf("%f",&s1[i].gpa);
   }

    for(i=0;i<30;i++)
   {
       printf("%d ",s1[i].roll);
       printf("%s ",s1[i].name);
       printf("%f ",s1[i].gpa);
       printf("\n");
   }
    return 0;
}

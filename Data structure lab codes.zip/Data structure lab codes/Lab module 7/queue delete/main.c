#include <stdio.h>
#include <stdlib.h>

void  queudel(char queue[],int n,int front,int rear)
{
    int i;
    char item;
    if(front==-1)
    {
        printf("Underflow\n");
        return;
    }
    item=queue[front];
    if(front ==rear)
    {
        front=-1;
        rear=-1;
    }
    else if(front==n)
        front=1;
    else
        front++;
    for( i=front;i<=rear;i++)
    printf("%c",queue[i]);
    return;
}


int main()
{
     char queue[100]={'R','A','H','A','T'};
int rear=4,front=0,n=99;

    queudel(queue,n,front,rear);

    return 0;
}


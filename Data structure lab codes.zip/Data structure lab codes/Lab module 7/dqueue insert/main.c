#include <stdio.h>
#include <stdlib.h>


void   dqueueins(char queue[],int n,int left,int right,char item)
{
    int i;
    if((left == 0 && right== n)||(left==right+1))
    {
        printf("OVERFLOW\n");
        return;
    }
    if(right==-1)
    {
        left=0;
        right=0;
    }
    else if(right==n)
        right=0;
    else
        right++;

    queue[right]=item;
     for( i=left;i<=right;i++)
    printf("%c",queue[i]);
    return;
}

int main()
{
     char queue[100]={'R','A','H','A','T'};
int left=0,right=4,n=99;

    dqueueins(queue,n,left,right,'U');
    return 0;
}

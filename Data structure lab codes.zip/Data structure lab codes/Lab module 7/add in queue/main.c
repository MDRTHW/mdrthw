#include <stdio.h>


void queu(char queue[],int n, int front, int rear,char item)
{
    int i;
    if((front == 0 && rear==n) ||  (front==rear+1))
    {
        printf("Overflow.Returning...\n");
        return;
    }
    else if(front == -1)
    {
        front=0;
        rear=0;
    }
    else if(rear==n)
    {
        rear=0;
    }
    else
        rear++;
    queue[rear]=item;

   for( i=0;i<=rear;i++)
    printf("%c",queue[i]);
}

int main()
{
     char queue[100]={'R','A','H','A','T'};
int rear=4,front=0,n=99;

    queu(queue,n,front,rear,'R');

    return 0;
}

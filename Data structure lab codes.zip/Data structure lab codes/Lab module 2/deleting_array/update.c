#include <stdio.h>

   int main() {
   int LA[100] = {1,3,5,7,8};
   int k = 3, n = 5, x= 10;
   int i;
   LA[k-1] = x;
 for(i = 0; i<n; i++)
      printf("LA[%d] = %d \n", i, LA[i]);
   }

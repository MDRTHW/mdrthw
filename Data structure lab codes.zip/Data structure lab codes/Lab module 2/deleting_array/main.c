#include <stdio.h>
int main()
{int  la[100]={1,2,3,4,5,6,7};
int j,k,n=7,x;
printf("Give the position of element to delete: ");
scanf("%d",&k);
k--;
x=la[k];
j=k;
while(j<n)
{la[j]=la[j+1];
j++;}
n=n-1;
for(int i=0;i<n;i++)
printf("%d\n",la[i]);
return 0;}

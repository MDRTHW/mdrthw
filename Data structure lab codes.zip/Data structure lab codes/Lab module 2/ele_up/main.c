#include <stdio.h>
int main()
{int a[100]={1,2,3,4,5,6,7};
int n=7,k,x;
printf("Give the location and element to upadte: ");
scanf("%d %d",&k,&x);
a[k-1]=x;
for(int i=0;i<n;i++)
printf("%d\n",a[i]);
return 0;}

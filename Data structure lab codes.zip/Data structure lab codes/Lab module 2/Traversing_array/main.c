#include <stdio.h>
int main()
{int a[100]={1,5,6,4,9,8,7,3,2,10};
int k,lb=0,ub=9;
k=lb;
while(k<=ub)
{printf("%d\n",a[k]);
k++;}
return 0;
}

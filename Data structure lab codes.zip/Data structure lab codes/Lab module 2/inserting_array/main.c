#include <stdio.h>
int main()
{int  la[100]={1,2,3,4,5,6,7};
int j,n=7,x,k;
printf("Give the position and value  of the element: ");
scanf("%d %d",&k,&x);
j=n -1;
k--;
while(k<=j){
la[j+1]=la[j];
j--;}
la[k]=x;
n=n+1;
for(int i=0;i<n;i++)printf("%d\n",la[i]);
return 0;
}

#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n,i=0,s1=0,s2=0,sp=0,m;
    string s;
    cin>>n;
    cin>>s;
    while(s[i]!='\0')
    {
        if(s[i]=='(')
            s1++;
        else
            s2++;

        if(s[i]=='('&&s[i+1]==')')
            sp=sp+2;


        i++;

    }
    s1--;
    s2--;
    m=min(s1,s2);
    if((s1==1&&s2==0)||(s1==0&&s2==1))
        cout<<"-1"<<endl;
    else
        cout<<m+sp+1<<endl;

   /// cout<<m<<"  "<<sp<<endl;
    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int t;
    int a[100],p[100],sw,m,n;
    cin>>t;

    while(t--)
    {
        cin>>n>>m;
        for(int i=1;i<=n;i++)
            cin>>a[i];
        for(int i=1;i<=m;i++)
            cin>>p[i];
        for(;;)
        {
            sw=0;
            for(int i=1;i<=m;i++)
            {
                if((p[i]-1)!=0)
                {
                    if(a[p[i]]<a[p[i]-1])
                        {swap(a[p[i]],a[p[i]-1]);
                        sw=1;}
                    if(a[p[i]]>a[p[i]+1])
                        {swap(a[p[i]],a[p[i]+1]);
                        sw=1;}
                }
                if((p[i]+1)==m)
                {
                    if(a[p[i]]<a[p[i]-1])
                        {swap(a[p[i]],a[p[i]-1]);
                        sw=1;}

                }
            }
            if(sw!=1)
                break;
        }
        for(int x: a)
            cout<<x<<"  ";
        cout<<endl;
    }
    return 0;
}

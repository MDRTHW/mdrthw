#include <bits/stdc++.h>

using namespace std;

int main()
{
    int a[3], n;
		cin >> a[0] >> a[1] >> a[2] >> n;
		sort(a, a + 3);
		n =n+ 2 * a[2] - a[1] - a[0];
		cout<<endl<<a[0]<<endl<<a[1]<<endl<<a[2]<<endl<<n<<endl;;
    return 0;
}

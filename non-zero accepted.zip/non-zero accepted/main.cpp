#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t,n,i,a[100];
    cin>>t;
    while(t--)
    {
        cin>>n;
        int sum=0,po=1,l=0;
        for( i=0;i<n;i++)
        {
            cin>>a[i];
            sum=sum+a[i];
            po=po*a[i];
        }
        for(i=0;i<n;i++)
            {
                if(a[i]==0)
                {
                    a[i]++;
                    l++;
                }

            }
            int sum2=0;
            for( i=0;i<n;i++)
            sum2=sum2+a[i];

        if(sum2==0)
            l++;

    cout<<l<<endl;
    }
    return 0;
}

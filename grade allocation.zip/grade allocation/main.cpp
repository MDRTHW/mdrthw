#include <bits/stdc++.h>

using namespace std;

int main()
{

    long long int t,m,n,s,x;

    cin>>t;
    while(t--)
    {
        s=0;
        cin>>n>>m;

        for(int i=0;i<n;i++)
        {
            cin>>x;
            s=s+x;
        }
        cout<<min(s,m)<<endl;
    }

    return 0;
}

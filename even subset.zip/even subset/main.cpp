#include <iostream>

using namespace std;

int main()
{
    int t,s[100],n,f=0,j,sum=0;

    cin>>t;
    while(t--)
    {
        cin>>n;
        f=0;
        for(int i=1;i<=n;i++)
            {cin>>s[i];
            if(s[i]%2==0)
                f=1;
            }
            if(f==1&&n!=1)
            {
                for( j=1;j<=n;j++)
                    if(s[j]%2==0)
                    break;
                cout<<"1"<<endl<<j<<endl;
                continue;
            }

            else  {if(n==1)
            {
                if(s[1]%2==1)
                cout<<"-1"<<endl;
                else
                    cout<<"1"<<endl<<"1"<<endl;
                    continue;

            }
            else
            {
                cout<<"2"<<endl<<"1 2"<<endl;
                continue;

            }}



    }
    return 0;
}

#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t,i=0,fp,lp,l=0;
    string s;
    cin>>t;
    while(t--)
    {
        int z=0;
        cin>>s;
        if(s=="0"||s=="1")
            z=0;
        else
        {
        while(s[i]!='\0')
        {
            if(s[i]=='1')
            {
              fp=i;
              break;
            }
            i++;
        }
        l=s.size();
        for(i=l;i>=0;i--)
        {
            if(s[i]=='1')
            {
                lp=i;
                break;
            }
        }
        for(i=fp;i<=lp;i++)
            if(s[i]=='0')
            z++;
        }

        cout<<z<<endl;

    }
    return 0;
}

#include <iostream>

using namespace std;


int gcd(int a,int b)
{
    if(a==0)
    return b;

    return gcd(b%a,a);

}


int main()
{
    int n,c=0,t,lcm=0,flag=0;

    cin>>t;
    while(t--){
    cin>>n;
    flag=0;
    for(int i=1;i<n;i++)
    {
        for(int j=1;j<n;j++)
        {

            c=gcd(i,j);
            lcm=(i*j)/c;
            if((c+lcm)==n)
            {
                cout<<i<<" "<<j<<endl;
                flag=1;
                break;
            }

        }
        if(flag==1)
            break;
    }
    }




    return 0;
}

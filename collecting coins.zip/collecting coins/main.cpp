#include <iostream>

using namespace std;

int main()
{
    int t,flag;
    int a,b,c,n,temp1;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        flag=0;
        cin>>a>>b>>c>>n;
        if(a>b&&a>c)
        {
            temp1=a-b;
            b=b+temp1;
            n=n-temp1;
            temp1=a-c;
            c=c+temp1;
            n=n-temp1;
            if(n<0||n%3!=0)
                flag=1;
        }
        else if(b>a&&b>c)
        {
            temp1=b-a;
            a=a+temp1;
            n=n-temp1;
            temp1=b-c;
            c=c+temp1;
            n=n-temp1;
            if(n<0||n%3!=0)
                flag=1;
        }
        else
        {
            temp1=c-a;
            a=a+temp1;
            n=n-temp1;
            temp1=c-b;
            b=b+temp1;
            n=n-temp1;
            if(n<0||n%3!=0)
                flag=1;
        }
        if(flag==1)
            cout<<"NO"<<endl;
        else
            cout<<"YES"<<endl;
    }
    return 0;
}

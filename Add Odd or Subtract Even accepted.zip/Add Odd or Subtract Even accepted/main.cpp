/// the minimum number of moves required to obtain b from a if you can perform any
///number of moves described in the problem statement. It is guaranteed that you can always obtain b from a.



#include <bits/stdc++.h>

using namespace std;

/// in any condition if the difference is odd then we will just add the diff.
/// but if the diff. id even then we have to add with extra one then
///reduce one


int main()
{
    int t;
    int a,b;

    cin>>t;

    for(int i=0;i<t;i++)
    {
        cin>>a>>b;
        if(a<b)
        {
            if((b-a)%2==1)
                cout<<"1"<<endl;
            else
                cout<<"2"<<endl;
        }
        else if(a==b)
        {
            cout<<"0"<<endl;
        }
        else
        {
            if((a-b)%2==0)
                cout<<"1"<<endl;
            else
                cout<<"2"<<endl;

        }

    }
    return 0;
}

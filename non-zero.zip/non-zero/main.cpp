#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t,n,i,a[100];
    cin>>t;
    while(t--)
    {
        cin>>n;
        int sum=0,po=1,l=0;
        for( i=0;i<n;i++)
        {
            cin>>a[i];
            sum=sum+a[i];
            po=po*a[i];
        }
        if(po==0&&sum==0)
            {
                int sum2=0;
                for(i=0;i<n;i++)
                {
                    if(a[i]==0)
                        {a[i]++;
                        l++;}
                    sum2+=a[i];
                }
                if(sum2==0)
                    {a[0]++;
                    l++;}

            }
        else if(po!=0&&sum==0)
        {
            int po2=1;
            a[0]++;

            for(i=0;i<n;i++)
                po2=po2*a[i];
            if(po2==0)
            {
                for(i=0;i<n;i++)
                {
                    if(a[i]==0)
                        {a[i]++;
                        l++;}
                }
                }
            else
                l=1;
        }
        else if(po==0&&sum!=0)
        {

            int sum2=0;
            for(i=0;i<n;i++)
                {
                    if(a[i]==0)
                        {a[i]++;
                        l++;}
                }

            for(i=0;i<n;i++)
                sum2=sum2*a[i];
            if(sum2==0)
            {
                l++;}
            else
                l=1;
        }

        else
            l=0;

    cout<<l<<endl;
    }
    return 0;
}

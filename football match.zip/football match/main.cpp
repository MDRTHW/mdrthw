#include <iostream>

using namespace std;

int main()
{
    int j=0,c=0;
    string s;
    char temp;

        cin>>s;
        temp=s[0];
        while(s[j]!='\0')
        {
            if(temp==s[j])
            {
                c++;
            }
            else
                c=0;
            if(c==7)
                break;
            temp=s[j];
            j++;
        }
        if(c==7)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;


    return 0;
}

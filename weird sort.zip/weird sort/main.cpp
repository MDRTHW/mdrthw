#include <iostream>

using namespace std;

bool  issort(int arr[100],int n)
{
    int flag=0;
    for(int i=0;i<n-1;i++)
    {
        if(arr[i+1]<arr[i])
        {
            flag=1;
            break;
        }
    }
    if(flag==1)
        return 0;
    else
        return 1;
}


int main()
{
    int t,m,n,flag=0;
    int a[100],p[100];
    cin>>t;

    for(int i=0;i<t;i++)
    {
        cin>>n>>m;

        for(int j=0;j<m;j++)
            cin>>a[j];
        for(int j=0;j<n;j++)
            cin>>p[j];
        if(issort(a,m)==1)
        {
            flag=1;
        }
        else
        {
            for(int i=0;i<m;i++)
            {
                swap(a[p[i-1]],a[p[i]]);
                if(issort(a,m)==1)
                {
                    flag=1;
                    break;
                }
            }
        }
        if(flag==1)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;

    }
    return 0;
}

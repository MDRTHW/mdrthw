#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t,x,y,a,b,i,s;
    cin>>t;
    for(i=0;i<t;i++)
    {
        s=1;
        cin>>x>>y>>a>>b;
        s=((y - x) % (a + b) == 0 ? (y - x) / (a + b) : -1);
        cout<<s<<endl;
    }

    return 0;
}

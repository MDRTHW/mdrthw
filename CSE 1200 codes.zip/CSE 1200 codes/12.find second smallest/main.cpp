#include <iostream>

using namespace std;

int main()
{
    int a[]={10,94,29,4,4,56,32,67,24,89};
    int n=10,s;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-1;j++)
        {
            for(int k=1;k<n;k++)
                if(a[k-1]>a[k])
                swap(a[k-1],a[k]);
        }
    }
    for(int i=0;i<n;i++)
    {
        if(a[i]!=a[i+1])
        {
            s=a[i+1];
            break;
        }
    }
    cout<<"The second smallest is "<<s<<endl;
    return 0;
}

#include <iostream>

using namespace std;

void insertionsort(int arr[],int n)
{
    int key,i,j;
    for(i=1;i<n;i++)
    {
        j=i-1;
        key=arr[i];
        while(j>=0&&arr[j]>key)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=key;
    }
    for(i=0;i<n;i++)
        cout<<arr[i]<<" "<<endl;
}

int main()
{
    int arr[]={5,2,8,4,1,9};
    int n=6;
    insertionsort(arr,n);
    return 0;
}

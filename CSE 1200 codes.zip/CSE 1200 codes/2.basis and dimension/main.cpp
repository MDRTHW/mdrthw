#include <bits/stdc++.h>
using namespace std;
int det(int mat[100][100], int n);
int d;

int det(int mat[100][100], int n)
{
int submat[100][100];
if(n==1)
    return mat[0][0];
else if(n==2)
    return (mat[0][0]*mat[1][1]-mat[1][0]*mat[0][1]);
else
{
    for(int c=0;c<n;c++)
    {
     int subi=0;
     for(int i=1;i<n;i++)
     {
       int subj=0;
         for(int j=0;j<n;j++)
          {
            if(j==c)
            continue;
            submat[subi][subj]=mat[i][j];
            subj++;}
        subi++;
     }
    d=d+(pow(-1,c) * mat[0][c] * det(submat,n-1));}}
    return d;
}

int main()
{
    int mat[100][100];
    int n;
    cout<<"Give the size of vector= "<<endl;
    cin>>n;
    cout<<"Now give the vector elements="<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<"Vector  "<<i+1<<"= ";
        for(int j=0;j<n;j++)
            cin>>mat[j][i];
        cout<<endl;
    }

    d=det(mat,n);
    if(d==0)
        cout<<"The matrix cannot form the basis of form R"
        <<n<<" because the determinant is zero."<<endl;
    else
        cout<<"The matrix can form the basis of form R"
        <<n<<" because the determinant is non-zero."<<endl;
    return 0;
}

#include <iostream>

using namespace std;

void bora(int a,int b,int c, int x,int y)
{
    int c1;
    c1=-(a*x+b*y);
    if(c1<c)
        cout<<"The point is above the line."<<endl;
    else if(c1==c)
        cout<<"The point is in the line."<<endl;
    else
        cout<<"The point is below the line."<<endl;
    return;
}

int main()
{
    int a,b,c,x,y;
    cout<<"Give the value of a,b,c as ax+by+c=0"<<endl;
    cin>>a>>b>>c;
    cout<<"Now give the point "<<endl;
    cin>>x>>y;
    bora(a,b,c,x,y);
    return 0;
}

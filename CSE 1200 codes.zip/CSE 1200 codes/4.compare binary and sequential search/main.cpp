#include <stdio.h>
int main()
{int la[100]={10,20,30,40,50,60,70,80,90};
int n=9,item,loc1=-1,k=0,llc=0;
scanf("%d",&item);
while(k<n)
{llc++;
if(la[k]==item)
{loc1=k;
break;}
k++;}
if(loc1!=-1)
printf("The location of %d by linear search is %d.\n",item,loc1+1);
else
printf("Item not found.\n");
printf("Loop needed= %d\n",llc);
int start=0,last=n-1,mid,blc=0,loc2=-1;
mid=(int)((start+last)/2);
while(start<=last)
{blc++;
if(item>la[mid])
start=mid+1;
else if(item==la[mid])
{loc2=mid;
break;}
else
last=mid-1;
mid=(int)((start+last)/2);}
if(loc2!=-1)
printf("The location of %d is by binary search is  %d.\n",item,loc2+1);
else
printf("Item not found.\n");
printf("Loop needed= %d\n",blc);
return 0;}

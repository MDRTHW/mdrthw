#include<bits/stdc++.h>
#define pii pair<int,int>
#define INF 1e9
#define mxn 1000
using namespace std;

vector<pii>adj[mxn];
int dis[mxn];
int n,e;
bool processed[mxn];

void Dijkstra(int x)
{
    for(int i=0;i<=n;i++)
        dis[i]=INF;
        dis[x]=0;
        priority_queue<pii>q;
        q.push({0,x});
        while(!q.empty())
        {
            int a=q.top().second;
            q.pop();
            if(processed[a])
                continue;
            processed[a]=true;
            for(auto u:adj[a])
                for(int u=0;u<adj[a].size();u++)
            {
                int b=u.first;
                int w=u.second;
                if(dis[a]+w<dis[b])
                {
                    dis[b]=dis[a]+w;
                    q.push({-dis[b],b});
                }
            }
        }

}

int main()
{
    cout<<"Enter node and link="<<endl;
    cin>>n>>e;
    for(int i=0;i<e;i++)
    {
        int u,v,w;
        cin>>u>>v>>w;
        adj[u].push_back({v,w});
        adj[v].push_back({u,w});
    }
    cout<<"Enter a source element: ";
    int s;
    cin>>s;
    Dijkstra(s);
    cout<<"Vertex "<<" "<<"Length"<<endl;
    for(int i=0;i<=n;i++)
    {
        cout<<i<<" "<<dis[i]<<endl;
    }
    return 0;
}

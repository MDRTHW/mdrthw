#include <bits/stdc++.h>

using namespace std;

int main()
{
    float x,y,z,x1,y1,z1;
    float v1v2,v1,v2;
    float ang;
    cout<<"Give the values for vector 1: ";
    cin>>x>>y>>z;
    cout<<"Give the values for vector 2: ";
    cin>>x1>>y1>>z1;
    v1v2=x*x1+y*y1+z*z1;
    v1=sqrt(x*x+y*y+z*z);
    v2=sqrt(x1*x1+y1*y1+z1*z1);
    ang=acos(v1v2/(v1*v2));
    cout<<"The angle is "<<ang<<"  radian."<<endl;

    return 0;
}

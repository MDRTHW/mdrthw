#include <bits/stdc++.h>

using namespace std;

void searchh(char *text, char *pat)
{
    int i,j;
    int m=strlen(text);
    int n=strlen(pat);
    for(i=0;i<m-n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(text[i+j]!=pat[j])
                break;
        }
         if (j == n)
            printf("Pattern found at index %d \n", i);
    }

}

int main()
{
    char *txt="AABAACAADAABAAABAA";
    char *pat ="AABA";
    searchh(txt,pat);
    return 0;
}

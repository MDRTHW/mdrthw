#include <bits/stdc++.h>

using namespace std;

#define N 3

class eqn{

public:
    float x[N+1];
    eqn(){for(int i=0;i<=N;i++) x[i]=0;}
    eqn operator-(eqn& eq)
    {
        eqn tmp;
        for(int i=0; i<=N; ++i)
            tmp.x[i] = x[i] - eq.x[i];
        return tmp;
    }

    static void elimination(eqn eq[])
    {
        eqn temp;
        float factor;
        for(int i=0;i<N;i++)
        {
            if(!eq[i].x[i])
            {

                for(int j=i+1;j<N;j++)
                {
                    if(eq[j].x[i]!=0)
                        swap(eq[i],eq[j]);
                }
                cout<<"Swaped"<<endl;
            }
            for(int k=0;k<N;k++)
            {
                if(i==k|| !eq[k].x[i])
                    continue;
                factor= eq[k].x[i]/eq[i].x[i];
                temp=factor*eq[i];
                eq[k]=eq[k]-temp;
            }
        }
        for(int i=0;i<N;i++)
        {
            factor=1/eq[i].x[i];
            eq[i]=factor*eq[i];
        }
         getans(eq);
    }

    friend bool det(eqn[]);
    friend eqn operator*(float c,eqn& eq);
    friend void getans(eqn[] );
};

eqn operator*(float c,eqn& eq)
{
    eqn tmp;
    for(int i=0;i<N;i++)
    {
        tmp.x[i]=c*eq.x[i];
    }
    return tmp;
}

void getans(eqn eq[]){
    cout<<"\n\nFinal Answer is:\n";
    cout<<"X= "<<eq[0].x[3]<<",\t";
    cout<<"Y= "<<eq[1].x[3]<<" and\t";
    cout<<"Z= "<<eq[2].x[3]<<"\n\n";
}

bool det(eqn eq[]){
    int sum = 0;
    sum += eq[0].x[0]*(eq[1].x[1]*eq[2].x[2]-eq[1].x[2]*eq[2].x[1]);
    sum -= eq[0].x[1]*(eq[1].x[0]*eq[2].x[2]-eq[1].x[2]*eq[2].x[0]);
    sum += eq[0].x[2]*(eq[1].x[0]*eq[2].x[1]-eq[1].x[1]*eq[2].x[0]);
    if(sum) return false;
    else return true;
}

int main()
{
    eqn eq[N];
    cout<<"Give the coefficient of the equations: "<<endl;
    for(int i=0;i<N;i++)
    {
        cout<<"For equation "<<i+1<<":";
        for(int j=0;j<=N;j++)
        cin>>eq[i].x[j];
    }
    if(det(eq))
        cout<<"There is no solution or there may be infinity solution."<<endl;
    else
        eqn::elimination(eq);
    return 0;
}

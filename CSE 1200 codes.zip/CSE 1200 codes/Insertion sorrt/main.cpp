#include <iostream>

using namespace std;

int main()
{
    int arr[100]={4,1,7,2,9,10};
    int j,i,temp,n=5;
    for(i=1;i<=n;i++)
    {
        temp=arr[i];
        j=i-1;
        while(j>=0&&arr[j]>temp)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=temp;
    }
    for(i=0;i<=n;i++)
        cout<<arr[i]<<" "<<endl;
    return 0;
}

#include<iostream>
using namespace std;
int main()
{
    int i,j,min_,loc,temp,count=0;
    int a[]={5,2,8,4,1,9};
    int n=6;
    for(i=0;i<n;i++)
        {
            min_=a[i];
            loc=i;
            for(j=i+1;j<n;j++){
            if(a[j]<min_){
                min_=a[j];
                loc=j;
                count++;
            }
            }
    swap(a[i],a[loc]);
    }
    cout<<endl;
for(i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
        }
    cout<<endl;
        cout<<"count="<<count;
return 0;
}

#include <bits/stdc++.h>

using namespace std;
///#define N 4
vector <int> gph1[100],gph2[100];
bool vis1[100],vis2[100];
void dfs1(int snode);
void dfs2(int snode);

bool is_connected(int node);

bool is_connected(int node)
{
    memset(vis1,false,sizeof vis1);
    dfs1(1);
    memset(vis2,false,sizeof vis2);
    dfs2(1);
    for(int i=0;i<=node;i++)
    {
        if(!vis1[i]&& !vis2[i])
            return false;
    }
    return true;
}

void dfs1(int snode)
{
    vis1[snode]=true;
    for(int i=0;i<gph1[snode].size();i++)
    {
        int u=gph1[snode][i];
        if(!vis1[u])
            dfs1(u);

    }
}

void dfs2(int snode)
{
    vis2[snode]=true;
    for(int i=0;i<gph2[snode].size();i++)
    {
        int u=gph2[snode][i];
        if(!vis2[u])
            dfs2(u);

    }
}

void add_edges(int u,int v)
{
        gph1[u].push_back(v);
        gph2[v].push_back(u);
}

int main()
{
    int node=4;
     add_edges(1,2);
     add_edges(1,3);
     add_edges(2,3);
     add_edges(2,4);
     if(is_connected(node))
        cout<<"The graph is connected"<<endl;
     else
        cout<<"The graph is not connected"<<endl;
    return 0;
}

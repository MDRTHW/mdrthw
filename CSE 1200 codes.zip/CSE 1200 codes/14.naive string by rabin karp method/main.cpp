#include <bits/stdc++.h>
using namespace std;
#define d 256

void get_input(vector <char>& a)
{
    char c;
    while(1){
    c=getchar();
    if(c=='\n')
        break;
    a.push_back(c);
    }
    return;
}

void searchh(char *text,char *pat,int q)
{
    int m;
    m=strlen(pat);
    int n;
    n=strlen(text);
    int i,j;
    int p=0,t=0,h=1;

    for(i=0;i<m-1;i++)
        h=(h*d)%q;

    for(i=0;i<m;i++)
    {
        p=(d*p+pat[i])%q;
        t=(d*t+text[i])%q;
    }

    for(i=0;i<=n-m;i++)
    {
        if(p==t)
        {
            for(j=0;j<m;j++)
            {
                if(text[i+j]!=pat[j])
                    break;
            }
            if(j==m)
            {
                cout<<"Pattern found at index "<<i<<endl;
            }

        }
        if(i<n-m)
        {
             t = (d * (t - text[i] * h) + text[i + m]) % q;
             if(t<0)
                t=t+q;
        }

    }

}


int main()
{
    vector <char> txt;
    vector <char> pat;
    cout<<"Enter the text: ";
    get_input(txt);
    cout<<"Give the pattern: ";
    get_input(pat);
    char *text,*patt;
    text=&txt[0];
    text[txt.size()]='\0';
    patt=&pat[0];
    patt[pat.size()]='\0';
    int q=103;
    searchh(text,patt,q);
    return 0;
}

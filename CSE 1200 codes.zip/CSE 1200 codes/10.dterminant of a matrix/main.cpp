#include <bits/stdc++.h>
# define N 100
using namespace std;

int det(int mat[N][N],int n)
{
    int d;
    int submat[N][N];
    int i,j,k;
    if(n==1)
        return mat[0][0];
    else if (n==2)
        return (mat[1][0]*mat[0][1]-mat[0][0]*mat[1][1]);
    else
{
    for(k=0;k<n;k++)
    {
        int subi=0, subj=0;
        for(i=1;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                submat[subi][subj]=mat[i][j];
                subj++;
            }
            subi++;
        }
        d=d+(pow(-1,k)*mat[0][k]*det(mat,n-1));
    }
}
return d;
}


int main()
{
    int mat[100][100]={{5,6,7},{7,6,1},{7,12,6}};
    int d,n=3;
    d=det(mat,n);
    cout<<"The result is "<<d<<endl;

    return 0;
}

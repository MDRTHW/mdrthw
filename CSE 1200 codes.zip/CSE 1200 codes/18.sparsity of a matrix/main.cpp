#include <iostream>

using namespace std;

int main()
{
    int matrix[100][100],zeros=0,m,n;
    int i,j;
    cout<<"Give the dimension of the matrix(m,n)= ";
    cin>>m>>n;
    cout<<endl;
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
           {
               cin>>matrix[i][j];
                if(matrix[i][j]==0)
                zeros++;
           }
    }
    if(((m*n)/2)<zeros)
        cout<<"This is a sparse matrix."<<endl;
    else
        cout<<"This is not a sparse matrix."<<endl;
    return 0;
}

#include <iostream>

using namespace std;

void solve(float a,float b,float c,float d)
{
    float x;

     if(a==c &&b==d)
        cout<<"There is infinity solution."<<endl;
    else if(a==c)
        cout<<"There is no solution."<<endl;
    else
        {x=(float)((d-b)/(a-c));
    cout<<"The result of X is = "<<x<<endl;}
}

int main()
{
    float a,b,c,d;
    cout<<"Give the coefficient of the equation:"<<endl<<"Ex: aX + b = cX + d"<<endl;
    cin>>a>>b>>c>>d;
    solve(a,b,c,d);
    return 0;
}

#include<bits/stdc++.h>
using namespace std;


class eqn{
public:
    float x, y, z, c;
    eqn(){
        x=0; y=0; z=0; c=0;
    }
    void seteqn(float x, float y, float z, float c){
        this->x=x;  this->y=y;
        this->z=z;  this->c=c;
    }
    eqn operator-(eqn& eq){
        eqn tmp;
        tmp.x=x-eq.x;    tmp.y=y-eq.y;
        tmp.z=z-eq.z;    tmp.c=c-eq.c;

        return tmp;
    }
    friend eqn operator*(float ,eqn& );
    friend void getans(eqn[] );
    friend void getmat(eqn[] );
    friend bool det(eqn[] );
};
eqn operator*(float c, eqn& eq){
    eqn tmp;
    tmp.x=c*eq.x;   tmp.y=c*eq.y;
    tmp.z=c*eq.z;   tmp.c=c*eq.c;

    return tmp;
}
void getans(eqn eq[]){
    cout<<"\n\nFinal Answer is:\n";
    cout<<"X= "<<eq[0].c/eq[0].x<<",\n";
    cout<<"Y= "<<eq[1].c/eq[1].y<<" and\n";
    cout<<"Z= "<<eq[2].c/eq[2].z<<"\n\n";
}
void getmat(eqn eq[] )
{
    cout<< "New matrix format:\n";
    for(int i=0; i<3; ++i)
        cout<<eq[i].x<<' '<<eq[i].y<<' '<<eq[i].z<<"\t|| "<<eq[i].c<<"\n";
}

bool det(eqn eq[])
{
    int sum = 0;
    sum += eq[0].x*(eq[1].y*eq[2].z-eq[1].z*eq[2].y);
    sum -= eq[0].y*(eq[1].x*eq[2].z-eq[1].z*eq[2].x);
    sum += eq[0].z*(eq[1].x*eq[2].y-eq[1].y*eq[2].x);

    if(sum) return false;
    else return true;
}


int main(){
    cout<<fixed;
    cout<<setprecision(1);
    eqn eq[3];
    while(1){
    int o;
    cout<<"Do you want to give input ?(0 for No & 1 for Yes)\n";
    cin>>o;
    if(o)
    {
        float a,b,c,d;
        for(int k=0;k<3;++k)
        {
            cout<<"Enter the co-efficients of ";
            cout<<k+1<<" number equation as a b c d\n";
            cin>>a>>b>>c>>d;
            eq[k].seteqn(a,b,c,d);
        }
    }
    else break;
    if(det(eq))
    {
        cout<<"\nNo solution or Infinity solution exists.\nTry again\n\n";
        continue;
    }
    eqn tmp;
    float factor;

    /// Finding co-efficient of x.
    if(!eq[0].x)
    {
        if(!eq[1].x)
            swap(eq[0], eq[2]);
        swap(eq[0], eq[1]);
    }

    cout<<"After swapping( or unchanged)\n";
    /// Show matrix.
    getmat(eq);

    /// Eliminate x of eqn2
        factor = eq[1].x/eq[0].x;
        tmp = (factor*eq[0]);
        eq[1] = eq[1]-tmp;

    /// Eliminate x of eqn3
        factor = eq[2].x/eq[0].x;
        tmp = (factor*eq[0]);
        eq[2] = eq[2]-tmp;

    cout<<"After Eliminating x\n";
    /// Show matrix.
    getmat(eq);

    /// Finding co-efficient of y.

    if(!eq[1].y)
        swap(eq[1], eq[2]);

    cout<<"After swapping( or unchanged)\n";
    /// Show matrix.
    getmat(eq);

    /// Eliminate y of eqn1
        factor = eq[0].y/eq[1].y;
        tmp = factor*eq[1];
        eq[0] = eq[0]-tmp;

    /// Eliminate y of eqn3
        factor = eq[2].y/eq[1].y;
        tmp = factor*eq[1];
        eq[2] = eq[2]-tmp;

    cout<<"After Eliminating y\n";
    /// Show matrix.
    getmat(eq);

    /// Eliminate z of eqn1
        factor = eq[0].z/eq[2].z;
        tmp = factor*eq[2];
        eq[0] = eq[0]-tmp;

    /// Eliminate z of eqn2
        factor = eq[1].z/eq[2].z;
        tmp = factor*eq[2];
        eq[1] = eq[1]-tmp;

    cout<<"After Eliminating z\n";
    /// Show matrix.
    getmat(eq);

    getans(eq);
    }

    return 0;
}

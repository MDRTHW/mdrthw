#include <bits/stdc++.h>

using namespace std;

class eqn
{
public:
    float x,y,z,c;
    eqn()
    {
        x=0;
        y=0;
        z=0;
        c=0;
    }

    void setvalue(int x,int y,int z,int c)
    {
        this->x=x;
        this->y=y;
        this->z=z;
        this->c=c;
    }
    eqn operator-(eqn& eq){
        eqn tmp;
        tmp.x=x-eq.x;    tmp.y=y-eq.y;
        tmp.z=z-eq.z;    tmp.c=c-eq.c;

        return tmp;
    }
    friend eqn operator*(float ,eqn& );
    friend void getans(eqn[] );
    friend void getmat(eqn[] );
    friend bool det(eqn[] );
};

eqn operator*(float c, eqn& eq){
    eqn tmp;
    tmp.x=c*eq.x;   tmp.y=c*eq.y;
    tmp.z=c*eq.z;   tmp.c=c*eq.c;

    return tmp;
}

void getans(eqn eq[]){
    cout<<"\n\nFinal Answer is:\n";
    cout<<"X= "<<eq[0].c/eq[0].x<<",\n";
    cout<<"Y= "<<eq[1].c/eq[1].y<<" and\n";
    cout<<"Z= "<<eq[2].c/eq[2].z<<"\n\n";
}

void getmat(eqn eq[] )
{
    cout<< "New matrix format:\n";
    for(int i=0; i<3; ++i)
        cout<<eq[i].x<<' '<<eq[i].y<<' '<<eq[i].z<<"\t|| "<<eq[i].c<<"\n";
}

bool det(eqn eq[])
{
    float sum=0;
    sum += eq[0].x*(eq[1].y*eq[2].z-eq[1].z*eq[2].y);
    sum -= eq[0].y*(eq[1].x*eq[2].z-eq[1].z*eq[2].x);
    sum += eq[0].z*(eq[1].x*eq[2].y-eq[1].y*eq[2].x);
    if(sum) return false;
    else return true;
}

int main()
{
    //cout<<fixed;
    cout<<setprecision(1);
    float a,b,c,d;
    eqn equ[3];
    for(int k=0;k<3;k++)
    {
        cout<<k+1<<"no equation coefficient= "<<endl;
        cin>>a>>b>>c>>d;
        equ[k].setvalue(a,b,c,d);
    }
    if(det(equ))
        cout<<"There is no solution or there may be infinity solution."<<endl;
    else
    {
        eqn temp;
        float factor;
        if(!equ[0].x)
        {
            if(!equ[1].x)
                swap(equ[0].x,equ[2].x);
            swap(equ[0].x,equ[1].x);

        }
        cout<<"After swapping"<<endl;
        getmat(equ);
        ///eliminating x from eu2
        factor=equ[1].x/equ[0].x;
        temp=factor*equ[0];
        equ[2] = equ[2]-temp;

        cout<<"After Eliminating x\n";
    /// Show matrix.
    getmat(equ);

    /// Finding co-efficient of y.

    if(!equ[1].y)
        swap(equ[1], equ[2]);

    cout<<"After swapping( or unchanged)\n";
    /// Show matrix.
    getmat(equ);

    /// Eliminate y of eqn1
        factor = equ[0].y/equ[1].y;
        temp = factor*equ[1];
        equ[0] = equ[0]-temp;

    /// Eliminate y of eqn3
        factor = equ[2].y/equ[1].y;
        temp = factor*equ[1];
        equ[2] = equ[2]-temp;

    cout<<"After Eliminating y\n";
    /// Show matrix.
    getmat(equ);

    /// Eliminate z of eqn1
        factor = equ[0].z/equ[2].z;
        temp = factor*equ[2];
        equ[0] = equ[0]-temp;

    /// Eliminate z of eqn2
        factor = equ[1].z/equ[2].z;
        temp = factor*equ[2];
        equ[1] = equ[1]-temp;

    cout<<"After Eliminating z\n";
    /// Show matrix.
    getmat(equ);
    }
    getans(equ);
    return 0;

}

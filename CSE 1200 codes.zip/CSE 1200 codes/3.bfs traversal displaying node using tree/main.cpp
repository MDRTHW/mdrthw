#include<bits/stdc++.h>
using namespace std;

int vis[1000];
int node[]={1,2,3,4,5,6,7,8};
int link[]={0,2,5,8,9,10,11};
int c_node[]={2,3,1,4,5,1,6,7,2,2,3,3};
int forw[]={1,-1,3,4,-1,6,7,-1,-1,-1,-1,-1};
int l=sizeof(node)/sizeof(node[0]);
int cnt=0;

void bfs(int x)
{
    queue<int>q;
    q.push(x);
    vis[x]=1;
    ++cnt;
    while(!q.empty())
    {
        int v=q.front();
        q.pop();
        int i;
        for(i=0;i<l;i++)
            if(node[i]==v) break;
        int ptr=link[i];


        while(ptr!=-1)
        {
            int u=c_node[ptr];
            if(vis[u]==0)
            {
                vis[u]=1;
                q.push(u);
                ++cnt;
            }
            ptr=forw[ptr];

        }
    }
}


int main()
{
    bfs(1);
    cout<<"After traversing the tree: "<<endl;
    cout<<"Number of connected nodes: "<<cnt<<endl;
    cout<<"Connected nodes are: "<<endl;
    for(int i=0;i<=l;i++)
    {
        if(vis[i]==1)
            cout<<i<<" ";
    }
    cout<<endl;
    cout<<"Number of disconnected nodes:"<<l-cnt<<endl;
    if(l-cnt==0)
        cout<<"There is no disconnected node."<<endl;

}

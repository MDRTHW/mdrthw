#include <bits/stdc++.h>

using namespace std;

int counter=0,m=0;
vector <char>str[50];
char c[100],c1[100];
void permutate(char *w,int i, int len)
{
    if(i==len)
        {
            str[m].push_back(*w);
            m++;
        }
    else
    {
        for(int j=i;j<=len;j++)
        {
            swap(*(w+i),*(w+j));
            permutate(w,i+1,len);
            swap(*(w+i),*(w+j));

        }

    }
}

void show()
{
    for(int k=0;k<m;k++)
    {
        for(int l=0;l<str[k].size();l++){
           c[l]=str[k][l];
           c1[l]=str[k+1][l];
        }
        if(strcmp(c1,c))
            cout<<c<<endl;

    }
}

int main()
{
    char word[100];
    cout<<"Give the string= ";
    cin>>word;
    int len;
    len=strlen(word);
    permutate(word,0,len-1);
    show();
    return 0;
}

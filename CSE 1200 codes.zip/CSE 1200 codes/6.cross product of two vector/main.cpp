#include <bits/stdc++.h>
const int l=0;
const int h=10;

using namespace std;

int main()
{
   time_t seconds;
   time(&seconds);
   srand((unsigned int )seconds);
   int u1,u2,u3,v1,v2,v3;
   u1=rand()%(h-l+1)+l;
   u2=rand()%(h-l+1)+l;
   u3=rand()%(h-l+1)+l;
   v1=rand()%(h-l+1)+l;
   v2=rand()%(h-l+1)+l;
   v3=rand()%(h-l+1)+l;
   int uvi,uvj,uvk;
   uvi = u2 * v3 - v2 * u3;
   uvj = v1 * u3 - u1 * v3;
   uvk = u1 * v2 - v1 * u2;
   cout << "The cross product of the 2 vectors \n u = " << u1 << "i + " << u2
    << "j + " << u3 << "k and \n v = " << u1 << "i + " << u2 << "j +" << u3 << "k \n ";
   cout << "u X v : " << uvi << "i +" << uvj << "j+ " << uvk << "k ";
    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int t,x;
    cin>>t;
    while(t--)
    {
        cin>>x;
        cout<<"1 "<<x-1<<endl;
    }
    return 0;
}

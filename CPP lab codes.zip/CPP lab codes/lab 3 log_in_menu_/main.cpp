#include <iostream>
#include "user.h"
using namespace std;
int main()
{char i[30],p[20];
cout<<"Welcome to log in menu!!"<<endl;
cout<<"Give id and password"<<endl;
cin>>i>>p;
user ob(i,p);
ob.log_in();
 return 0;
}

#ifndef USER_H
#define USER_H


class user
{
    char id[30];
    char pass[20];
    public:
        user(char i[30], char p[20]);
        void log_in();
        ~user();

};

#endif // USER_H

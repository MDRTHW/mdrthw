#include "user.h"
#include <fstream>
#include <string.h>
#include <iostream>
using namespace std;
user::user(char i[30], char p[20])
{ofstream out;
strcat(i,".txt");
out.open(i);
out<<p<<endl;
out.close();}
void user:: log_in()
{ifstream in;
char passw[20],ids[30];
cout<<"Give the id and password to check"<<endl;
cin>>ids>>passw;
strcat(ids,".txt");
char pas[20];
in.open(ids);
if(in){in>>pas;
if(strcmp(passw,pas)==0)
cout<<"Login successful"<<endl;
else
cout<<"Wrong password!!"<<endl;}
else
cout<<"Account does not exits"<<endl;}
user::~user()
{cout<<"Program closed"<<endl;}

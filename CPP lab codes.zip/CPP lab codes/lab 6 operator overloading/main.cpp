#include <iostream>

using namespace std;

class user{
    int *balance;
    static int no_of_user;
    static int total_balance;
public:
    user();
    user(int val);
    user operator+(user& u5);
    void show();
    void show2();
    ~user();
};
int user:: no_of_user=0;
int user::  total_balance=0;
user::user()
{
    balance=new int();
    *balance=0;
    no_of_user++;
}

user::user(int val)
{   balance=new int();
    *balance=val;
     no_of_user++;//check here
    total_balance=total_balance+*balance;
}

user user::operator+(user& u5)
{
    int tempo;
    tempo=*balance+*u5.balance;
    no_of_user++;
    total_balance=total_balance+*balance;
    user u7(tempo);
    return u7;
}

void user::show()
{
    cout<<*balance<<endl;

}

void user:: show2()
{
    float avg;
    avg=float(1.0*total_balance/no_of_user);
    cout<<"total_balance= "<<total_balance<<endl;
    cout<<"no_of_user= "<<no_of_user<<endl;
    cout<<"avg= "<<avg<<endl;
}

user::~user()
{
    //delete(balance);
}

int main()
{
   user u1(10);
   user u2(20);
   user u3(u2);
   user u4;

   u4=u3+u2;
   u1.show();
   u2.show();
   u3.show();
   u4.show();
   u4.show2();
    return 0;
}

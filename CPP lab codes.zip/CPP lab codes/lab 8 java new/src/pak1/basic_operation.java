package pak1;
import java.util.Scanner;

class point{
	private int x;
	private int y;
	public point() {
		x=0;
		y=0;
	}
	public point(int x,int y) {
		this.x=x;
		this.y=y;
	}
	public int get_x() {return x;}
	public int get_y() {return y;}
}

public class basic_operation {

	public static void main(String[] args) {
		//int a;
		//int b;
		Scanner input = new Scanner(System.in);
		int c;
		
		System.out.print("Give the input= ");
		c=input.nextInt();
		int d=input.nextInt();
		point ob1=new point(c,d);
		System.out.println(ob1.get_x()+" "+ob1.get_y());
		
		
		
		//String str=input.next();
		//for(int i=0;i<c;i++)
			//System.out.println(i);
		//System.out.println(c+" "+str);
	}

}

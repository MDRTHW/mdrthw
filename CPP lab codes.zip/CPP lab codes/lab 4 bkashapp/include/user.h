#ifndef USER_H
#define USER_H
class user
{
    char mobile_no[20];
    char pin[10];
    char balance[10];
    int inbal;
    public:
    void registration();
    void log_in();
    void process();
    void withdraw();
    void deposit();
    void cekbal();
    void write();
    ~user();
};

#endif // USER_H

#include <iostream>
#include "user.h"
using namespace std;
int main()
{user us1;
int n;
cout<<"Welcome to bkashnahid banking system"<<endl;
for(;;)
{cout<<"What you want to do?"<<endl;
cout<<"1.Log in "<<endl<<"2. Registration"<<endl<<"3. Exit"<<endl;
cin>>n;
if(n==1)
{cout<<"Trying to log in?"<<endl;
us1.log_in();}
else if(n==2)
{cout<<"Wanna open an account?"<<endl;
us1.registration();}
else
{cout<<"Thanks for sharing our service"<<endl;
break;}}
return 0;
}

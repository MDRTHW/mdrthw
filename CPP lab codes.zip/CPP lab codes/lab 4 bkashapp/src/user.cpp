#include "user.h"
#include <fstream>
#include <string.h>
#include <iostream>
using namespace std;
void user::log_in()
{
ifstream in;
char passw[10], mobil[20],extra[20];
cout<<"Give the mobile no and pin to check:"<<endl;
cin>>mobile_no>>passw;
strcpy(mobil,mobile_no);
strcat(mobil,".txt");
in.open(mobil);
if(in)
{
in>>extra>>pin;
if(strcmp(passw,pin)==0){
cout<<"Login successful"<<endl;
process();}
else
cout<<"Wrong password!!"<<endl;}
else
cout<<"Account does not exist"<<endl;}

void user::registration()
{
cout<<"Give phone number:+88";
cin>>mobile_no;
cout<<endl<<"Give pin number: ";
cin>>pin;
cout<<endl<<"Give the initial deposit: ";
cin>>balance;
ofstream out;
char mobil[20];
strcpy(mobil,mobile_no);
strcat(mobil,".txt");
out.open(mobil);
out<<mobile_no<<endl;
out<<pin<<endl;
out<<balance<<endl;
out.close();}

void user:: process()
{
int n;
for(;;){
cout<<"What you want to do?"<<endl;
cout<<"1. Withdraw money"<<endl<<"2. Deposit money"<<endl<<"3. Check balance"<<endl<<"4.Exit"<<endl;
cin>>n;
if(n==1)
withdraw();
else if(n==2)
deposit();
else if(n==3)
cekbal();
else {
    break;
cout<<"Returning to the main menu."<<endl;}}}

 void user::withdraw()
{
char mobil[20],passw[20];
int widwbal;
cout<<"Enter the pin: ";
cin>>pin;
ifstream in;
strcpy(mobil,mobile_no);
strcat(mobil,".txt");
in.open(mobil);
in>>mobile_no>>passw>>inbal;
if(strcmp(passw,pin)==0){
cout<<"Give the withdraw amount"<<endl;
cin>> widwbal;
if(inbal>500)
inbal=inbal-widwbal;
else
cout<<"You don't have sufficient balance to withdraw."<<endl;
write();
in.close();}
else
cout<<"Wrong password!!"<<endl;}


 void user:: deposit()
{
char mobil[20],passw[20];
int dipbal;
cout<<"Enter the pin: ";
cin>>pin;
ifstream in;
strcpy(mobil,mobile_no);
strcat(mobil,".txt");
in.open(mobil);
in>>mobile_no>>passw>>inbal;
if(strcmp(passw,pin)==0){
cout<<"Give the deposit amount"<<endl;
cin>> dipbal;
inbal=inbal+dipbal;
write();
in.close();}
else
cout<<"Wrong password!!"<<endl;}

 void user:: cekbal()
 {
char mobil[20],passw[20];
cout<<"Enter the pin: ";
cin>>pin;
ifstream in;
strcpy(mobil,mobile_no);
strcat(mobil,".txt");
in.open(mobil);
in>>mobile_no>>passw>>inbal;
if(strcmp(passw,pin)==0){
cout<<"Your current account balance is= ";
cout<<inbal<<endl;
in.close();}
else
cout<<"Wrong password!!"<<endl;}


void user:: write()
{
ofstream out;
char mob[20];
strcpy(mob,mobile_no);
strcat(mobile_no,".txt");
out.open(mobile_no);
out<<mob<<endl;
out<<pin<<endl;
out<<inbal<<endl;
out.close();}

user::~user()
{
cout<<"Hope to see you soon"<<endl;
}

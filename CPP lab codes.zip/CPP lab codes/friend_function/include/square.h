#ifndef SQUARE_H
#define SQUARE_H

class square
{
    float side;
    float area;
    public:
        friend class cude;
        square(float x);
        friend void print_square(square& s1);
        friend cude(square& s1);

};

#endif // SQUARE_H

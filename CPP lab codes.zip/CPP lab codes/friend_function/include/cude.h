#ifndef CUDE_H
#define CUDE_H


class cude
{
    float side;
    float volume;
    public:
        cude();
        friend void print_cube(cude& c1);
};

#endif // CUDE_H

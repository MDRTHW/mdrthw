#include <iostream>
#include "square.h"
#include "cude.h"
using namespace std;

int main()
{
    square s1(10);
    cude c1;
    print_square(s1);
    print_cube(c1);
    return 0;
}

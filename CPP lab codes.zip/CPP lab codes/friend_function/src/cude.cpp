#include "cude.h"
#include <iostream>
using namespace std;
cude::cude(square& s1)
{
    side=s1.side;
    volume=side*side*side;
}
 void print_cube(cude& c1)
 {
     cout<<"Side "<<c1.side<<"Area  "<<c1.side<<endl;
 }


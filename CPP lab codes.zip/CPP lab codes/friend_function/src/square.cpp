#include "square.h"
#include <iostream>
using namespace std;
square::square(float x)
{
    side=x;
   area=side*side;
}


void print_square(square& s1)
{
    cout<<"Side  "<<s1.side<<"  Area  "<<s1.area<<endl;
}

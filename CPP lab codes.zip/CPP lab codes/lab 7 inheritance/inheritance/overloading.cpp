#include<iostream>

using namespace std;
class rupok{
    int sum=10;
public:
    void set_value(int a,int b);
    int output();
    void set_value(int a,int b,int c);

};
void rupok::set_value(int a,int b)
{
    sum=a+b;
}
int rupok::output()
{
    return sum;
}
void rupok::set_value(int a,int b,int c)
{
    sum=a+b+c;
}
int main()
{

    rupok kx,bx;
    kx.set_value(5,6);
    bx.set_value(1,2,3);
    cout<<"The first one is:"<<kx.output()<<endl;
    cout<<"The second one is:"<<bx.output()<<endl;
    return 0;




}















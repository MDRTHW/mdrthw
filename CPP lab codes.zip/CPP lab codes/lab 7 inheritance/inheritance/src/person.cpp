#include "person.h"
#include <bits/stdc++.h>
using namespace std;
person::person(string n,int a,string mob)
{name=n;
age=a;
mobile_no=mob;}
student::student(string rol, float gp,string nam,int ag, string mob):
person(nam,ag,mob)
{roll=rol;
gpa=gp;}
teacher:: teacher(string tid,string join,string degi,string nam, int ag,string mob):
person(nam,ag,mob)
{teacher_id=tid;
joinning_date=join;
designation=degi;}
void teacher::printinfo()
{cout<<teacher_id<<" ";
cout<<joinning_date<<" ";
cout<<designation<<" ";
person::printinfo();}
void student::printinfo()
{cout<<roll<<" ";
cout<<gpa<<" ";
person::printinfo();}
void person::printinfo()
{cout<<name<<" ";
cout<<age<<" ";
cout<<mobile_no<<endl;}

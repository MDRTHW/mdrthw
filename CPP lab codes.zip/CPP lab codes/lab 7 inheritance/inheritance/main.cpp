#include <bits/stdc++.h>
#include "person.h"
using namespace std;
int main()
{cout<<"TEACHER:";
teacher t1("1013","251016","lecturer","Rahat",65,"01915");
t1.printinfo();
cout<<endl;
cout<<"STUDENT:";
student st1("123",3.5,"Rahat",20,"0198");
st1.printinfo();
cout<<endl;
return 0;}

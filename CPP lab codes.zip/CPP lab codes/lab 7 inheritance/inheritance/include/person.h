#ifndef PERSON_H
#define PERSON_H
#include <bits/stdc++.h>
using namespace std;
class person
{public:
string name;
protected:
string mobile_no;
private:
int age;
public:
person(string,int a,string);
void printinfo();};
class student: public person
{string roll;
float gpa;
public:
student(string , float gp,string ,int ag, string );
void printinfo();};
class teacher: private person
{string teacher_id;
string joinning_date;
string designation;
public:
teacher(string , string , string ,string , int ag,string);
void printinfo();};

#endif // PERSON_H

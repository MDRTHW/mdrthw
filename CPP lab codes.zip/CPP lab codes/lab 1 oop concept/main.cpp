#include <iostream>

using namespace std;

class poi {
 int x,y,r;

 public:
     poi (){
        x=0;
        y=0;
        r=0;
     }
     poi (int h, int j){
        x=h;
        y=j;
     }
     void addition(){
        r=x+y;
     }
     void substraction(){
        r=x-y;
     }
     void divition(){
        r=x/y;
     }
     void multiplication(){
     r=x*y;
     }
     int get_re()
     {
         return r;
     }
};


int main()
{
    int a,b;
    poi p1(45,22);
    p1.addition();

     poi p2(60,20);
     p2.substraction();

    poi p3(70,10);
    p3.divition();

     poi p4(40,20);
    p4.multiplication();
     cout <<p2.get_re() << endl;
      cout <<p1.get_re() << endl;
     cout <<p3.get_re() << endl;
     cout <<p4.get_re() << endl;




    return 0;
}

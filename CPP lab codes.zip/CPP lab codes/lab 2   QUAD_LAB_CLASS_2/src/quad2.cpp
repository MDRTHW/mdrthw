#include "quad2.h"
#include <math.h>
#include <iostream>
using namespace std;
quad2::quad2()
{
    x=0;
    y=0;
    area=0;
    cout<<"Constructor is called"<<endl;
}

quad2::quad2(int a)
{
    x=a;
    y=a;
    area=x*y;
    cout<<"Constructor is called"<<endl;
}
quad2::quad2 (int a,int b)
{
    x=a;
    y=b;
    area=x*y;
    cout<<"Constructor is called"<<endl;
}
quad2::quad2 (float a,float b,float c)
{
    x=a;
    y=b;
    area=y*x*sin((3.1416/180)*c);
    cout<<"Constructor is called"<<endl;
}
float quad2:: get_area()
{

    return area;
}
quad2::~quad2()
{
    cout<<"destructor is executed"<<endl;
}

#include <iostream>
#include "quad2.h"

using namespace std;

int main()
{
    quad2 q1(20);
    cout<<q1.get_area()<<endl;
    quad2 q2(15,10);
    cout<<q2.get_area()<<endl;
    quad2 q3(16,27,60);
    cout<<q3.get_area()<<endl;
    return 0;
}

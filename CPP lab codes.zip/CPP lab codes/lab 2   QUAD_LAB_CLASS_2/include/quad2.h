#ifndef QUAD2_H
#define QUAD2_H


class quad2
{
    int x;
    int y;
    float area;

    public:
        quad2();           //general contructor when no value is paased
        quad2(int a);   // when value is passed , and these constructor are called automatically when object is created
        quad2 (int a,int b);
        quad2(float a,float b,float c);
        float get_area();    // the required function to operation
        ~quad2();

};

#endif // QUAD_H
